﻿using System;

public class Bateau
{

	public Bateau(int X, int Y, int taille, string Name)
	{
        string BoatName;
        bool orientation = true; //true -> horizontal // false -> Vertical// 
        int Position_X = X;
        int Position_Y = Y;
        int Taille = taille;
        int Vie = Taille;
	}

}
